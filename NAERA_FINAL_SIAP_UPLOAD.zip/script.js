const nav=document.getElementById('nav');
const toggle=document.getElementById('menuToggle');
const isEnglish=document.documentElement.lang==='en';
function closeMenu(){nav.classList.remove('open');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label',isEnglish?'Open navigation menu':'Buka menu navigasi');toggle.textContent='☰'}
toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?(isEnglish?'Close navigation menu':'Tutup menu navigasi'):(isEnglish?'Open navigation menu':'Buka menu navigasi'));toggle.textContent=open?'×':'☰'});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
document.addEventListener('click',e=>{if(!nav.contains(e.target)&&!toggle.contains(e.target))closeMenu()});
document.getElementById('year').textContent=new Date().getFullYear();
const sectionLinks=[...nav.querySelectorAll('[data-section-link]')];
function updateActive(){let active='home';for(const section of document.querySelectorAll('main section[id]')){if(section.getBoundingClientRect().top<=145)active=section.id;}sectionLinks.forEach(a=>{if(a.getAttribute('href')==='#'+active)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current')})}
window.addEventListener('scroll',updateActive,{passive:true});window.addEventListener('hashchange',updateActive);updateActive();
const switchLink=nav.querySelector('.lang');if(switchLink)switchLink.addEventListener('click',()=>{const hash=window.location.hash;if(hash)switchLink.href=(isEnglish?'index.html':'index-en.html')+hash});
document.getElementById('contactForm').addEventListener('submit',e=>{e.preventDefault();const f=e.currentTarget;if(!f.reportValidity())return;const subject=encodeURIComponent('NAERA TRANSLATION — '+(isEnglish?'Translation Inquiry':'Permintaan Terjemahan'));const body=encodeURIComponent(`${isEnglish?'Name':'Nama'}: ${f.elements.name.value}
Email: ${f.elements.email.value}
${isEnglish?'Direction':'Arah penerjemahan'}: ${f.elements.direction.value}

${f.elements.message.value}`);window.location.href=`mailto:alineauliya19@gmail.com?subject=${subject}&body=${body}`});
