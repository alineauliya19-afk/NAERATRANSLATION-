NAERA TRANSLATION
Contoh hasil terjemahan.
