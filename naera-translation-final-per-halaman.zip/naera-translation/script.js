const nav = document.getElementById("nav");
const menuToggle = document.getElementById("menuToggle");
menuToggle?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.textContent = open ? "×" : "☰";
});
nav?.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle?.setAttribute("aria-expanded", "false");
  if (menuToggle) menuToggle.textContent = "☰";
}));
const year = document.getElementById("year");
if (year) year.textContent = new Date().getFullYear();

const form = document.getElementById("contactForm");
const statusBox = document.getElementById("formStatus");
const submitButton = document.getElementById("submitButton");

form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  statusBox.className = "form-status";
  statusBox.textContent = "";

  const name = form.elements.name.value.trim();
  const email = form.elements.email.value.trim();
  const direction = form.elements.direction.value;
  const message = form.elements.message.value.trim();
  if (name.length < 2 || !email || message.length < 10 || !direction) {
    statusBox.classList.add("error");
    statusBox.textContent = "Periksa kembali nama, email, arah bahasa, dan pesan Anda.";
    return;
  }

  submitButton.disabled = true;
  submitButton.textContent = "Mengirim...";
  try {
    const response = await fetch(form.action, {
      method: "POST",
      body: new FormData(form),
      headers: { "Accept": "application/json" }
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || result.success === "false" || result.success === false) {
      throw new Error("Pengiriman tidak berhasil");
    }
    statusBox.classList.add("success");
    statusBox.textContent = "Terima kasih! Pesan Anda sudah dikirim. Kami akan menghubungi Anda melalui email.";
    form.reset();
  } catch (error) {
    console.error("Form submission error:", error);
    statusBox.classList.add("error");
    statusBox.textContent = "Pesan belum berhasil dikirim. Coba lagi atau hubungi kami melalui WhatsApp/email.";
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = 'Kirim pertanyaan <span>↗</span>';
  }
});
